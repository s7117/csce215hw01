#include "../inc/main.hpp"

int main() {
  std::cout << "Welcome to TicTacToe" << std::endl;
  TicTacToe game;
  game.playgame();
  return 0;
}
