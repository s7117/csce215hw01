#ifndef MAIN_H
#define MAIN_H

#include <iostream>
#include "../inc/board.hpp"

#endif
